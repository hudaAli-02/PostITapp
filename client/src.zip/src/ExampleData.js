export const UserData=[
    {
    name: "Ali",
    email: "ali@gmail.com",
    password: "12345",
    },
    {
        name: "Aisha",
        email: "aisha@gmail.com",
        password: "abcde"
    },
    {
        name: "zaid",
        email:"zaid@gmail.com",
        password:"1234ha",
    },
]